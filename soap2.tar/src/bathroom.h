/**********
** bathroom.h -- class prototype for Bathroom
**
** Project: SOAP2
** Author: Eli Wenig
**
**********/
#ifndef BATHROOM_H
#define BATHROOM_H
#include <string>
#include <vector>
#include <pthread.h>

using namespace std;

class Bathroom {
    public:
    	Bathroom(string,short);
        string getLocation();
	short getAlsaNum();
	void play();
	static void playNext_wrapper(void*);
	static Bathroom* getBathroomByName(string);
	static string** listAllBathrooms();
	int addToQueue(string);

    private:
	//attributes
        string location;
        vector<string> queue;
	short alsaNum;
	pthread_t playThread;

	//methods
	void playNext();
	void checkNext();
};
#endif
