/**********
** config.cpp -- configuration file for SOAP2
**
** Project: SOAP2
** Author: Eli Wenig
**
**********/
#ifndef CONFIG_H
#define CONFIG_H
#include <cstdlib>
#include "bathroom.h"

extern const short PORTNUM = 1234;
extern const int MAX_QUEUE_SIZE = 5; //Maximum number of songs that can be in one queue
#ifdef SOAPDEBUG
extern const int TIMEOUT = 5; //Stream timeout
#else
extern const int TIMEOUT = 15 * 60; //Stream timeout
#endif

extern const int NUM_BATHROOMS = 3;

extern const char LOGFILE[30] = "log/soap.log";

Bathroom *myBathrooms[3] = {
//	The following code controls how the bathrooms correspond to the ALSA outputs.
//	They might be changed following a reboot, so you can change this code
//	instead of swapping physical inputs.
	new Bathroom("The L",2),
	new Bathroom("The Stairs",1),
	new Bathroom("The Vator",0)
};

#endif
