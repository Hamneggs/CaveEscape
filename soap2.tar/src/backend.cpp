/**********
** backend.h -- class definitions for the SOAP2 backend
**
** Project: SOAP2
** Author: Eli Wenig
**
**********/
#include <iostream>
#include <cassert>
#include <xmlrpc-c/base.hpp>
#include <xmlrpc-c/registry.hpp>
#include <xmlrpc-c/server_abyss.hpp>
#include "backend.h"
#include "bathroom.h"
#include "logger.h"

using namespace std;
using namespace xmlrpc_c;

Backend::Backend(short port) {
	try {
		this->port = port;
	
		//construct method pointers and pass them to the registry
		methodPtr const playStreamPtr(new playStream);
		methodPtr const crappersPtr(new crappers);
		this->myReg.addMethod("playStream",playStreamPtr);
		this->myReg.addMethod("crappers",crappersPtr);
	
		//construct our server object
		serverAbyss myServer(
			serverAbyss::constrOpt().registryP(&this->myReg).portNumber(this->port)
		);

		//enter server blocking loop
		extern Logger myLogger;
		myLogger.log("XMLRPC server started");
		cout.flush();
		myServer.run();

		//in case the server returns, which it shouldn't
		assert(false);
	} catch (exception& e) {
		extern Logger myLogger;
		myLogger.logf("Exception caught in XMLRPC server loop: %s",e.what());
	}
}

playStream::playStream() : method() {
	this->_signature = "s:ss";
	this->_help = "playStream() adds a stream to the queue.";
}

void playStream::execute(paramList const& params, value* const retvalP) {
	extern Logger myLogger;
	myLogger.log("Servicing playStream() request");
	string location,stream;

	try {
		location = params.getString(0);
		stream = params.getString(1);
	} catch (exception& e) {
		*retvalP = value_string("FAILURE");
		myLogger.logf("Exception caught in playStream(): %s",e.what());
		return;
	}

	try {
		//do url sanity checking
		if (!(stream.substr(0,4).compare("http") == 0 ||
		    stream.substr(0,3).compare("ftp") == 0 ||
		    stream.substr(0,5).compare("https") == 0)) {
			throw new exception;
		}
	} catch (exception& e) {
		*retvalP = value_string("BAD URI");
		myLogger.logf("Exception caught in playStream(): %s",e.what());
		return;
	}

	Bathroom *myBathroom = Bathroom::getBathroomByName(params.getString(0));
	if (myBathroom == NULL) {
		*retvalP = value_string("NOT FOUND");
		return;
	}

	if (myBathroom->addToQueue(stream) != 0) {
		//failure
		*retvalP = value_string("BIG QUEUE");
		return;
	}

    	myBathroom->play();

	cout << "In after wait?\n";
	*retvalP = value_string("OK");
}

crappers::crappers() : method() {
	this->_signature = "s:";
	this->_help = "crappers() returns a list of valid bathroom names.";
}

void crappers::execute(paramList const& params, value* const retvalP) {
	extern Logger myLogger;
	myLogger.log("Servicing crappers() request");
	cout.flush();

	extern int NUM_BATHROOMS;
	string **b = Bathroom::listAllBathrooms();
	vector<value> bathroomsData;
	for (int i=0;i<NUM_BATHROOMS;i++) {
		bathroomsData.push_back(value_string(*b[i]));
	}

	value_array retvalArr(bathroomsData);
	*retvalP = retvalArr;
}
