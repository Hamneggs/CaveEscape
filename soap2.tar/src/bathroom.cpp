/**********
** bathroom.cpp -- class definitions for Bathroom
**
** Project: SOAP2
** Author: Eli Wenig
**
**********/
#include <iostream>
#include <string>
#include <cstdlib>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>
#include <signal.h>
#include "bathroom.h"
#include "logger.h"

using namespace std;

//constructor
Bathroom::Bathroom(string location,short alsaNum) {
	extern const int MAX_QUEUE_SIZE;

	this->playThread = 0;
	this->queue.reserve(MAX_QUEUE_SIZE);

	this->location = location;
	this->alsaNum = alsaNum;
}

//accessors
string Bathroom::getLocation() {
	return this->location;
}

short Bathroom::getAlsaNum() {
	return this->alsaNum;
}

//Play the next song in the queue.
void Bathroom::playNext() {
	extern const int TIMEOUT;
	extern Logger myLogger;

	//In the child process
	const char *streamUrl = this->queue.front().c_str();
	//get rid of the stream url in the queue now
	this->queue.erase(this->queue.begin());
	//prepare and execute our command
	char *cmdStr;
#ifndef SOAPDEBUG
	asprintf(&cmdStr,"timeout -s SIGKILL %d mplayer -cache 1024 -noconsolecontrols -ao alsa:device=hw=%d.0 %s",TIMEOUT,this->alsaNum,streamUrl);
#else
//	asprintf(&cmdStr,"timeout -s SIGKILL %d mplayer -cache 1024 -noconsolecontrols -ao null %s &",TIMEOUT,streamUrl);
	asprintf(&cmdStr,"sleep 15");
#endif
	system(cmdStr);
	//play the next file, if there is one
	this->checkNext();
	cout << "We got here\n";
}

//Wrapper for the above function (assists in pthread_create)
void Bathroom::playNext_wrapper(void* myContext) {
	Bathroom* myBathroom = (Bathroom*) myContext;

	myBathroom->playNext();
}

//Pop a stream onto the queue.
int Bathroom::addToQueue(string url) {
	extern const int MAX_QUEUE_SIZE;

	if (this->queue.size() >= MAX_QUEUE_SIZE)
		return 1;

	this->queue.push_back(url);
	return 0;
}

//Start playing a song, but not if we're already doing so.
void Bathroom::play() {
	if (this->playThread) return;
	else {
		pthread_attr_t attr;
		pthread_attr_init(&attr);
		pthread_attr_setdetachstate(&attr,PTHREAD_CREATE_DETACHED);
		if(int err = pthread_create(&this->playThread,&attr,(void* (*)(void*))Bathroom::playNext_wrapper,this)) {
			extern Logger myLogger;
			myLogger.logf("Error in pthread_create for bathroom %s, code %d",this->location.c_str(),err);
		}
	}
}

//Is there another song in the queue? If yes, play it
void Bathroom::checkNext() {
	if (this->queue.size() > 0) {
		this->playNext();
	} else {
		this->playThread = 0;
		pthread_exit(NULL);
	}
}

//Get a bathroom by its location
Bathroom* Bathroom::getBathroomByName(string name) {
	extern Bathroom *myBathrooms[3];
	extern const int NUM_BATHROOMS;

	for (int i=0;i<NUM_BATHROOMS;i++) {
		if (name.compare(myBathrooms[i]->getLocation()) == 0) {
			return myBathrooms[i];
		}
	}

	return NULL;
}

//Used by the crappers() call
string** Bathroom::listAllBathrooms() {
	extern Bathroom *myBathrooms[3];
	extern const int NUM_BATHROOMS;

	string** res = (string**) calloc(sizeof(string*),NUM_BATHROOMS);

	for (int i=0;i<NUM_BATHROOMS;i++) {
		res[i] = new string(myBathrooms[i]->getLocation());
	}

	return res;
}
