/**********
** SOAP2.cpp -- main loop for SOAP2
**
** Project: SOAP2
** Author: Eli Wenig
**
**********/
#include <iostream>
#include <cstdlib>
#include "backend.h"
#include "logger.h"

using namespace std;

int main() {
    extern const short PORTNUM;
    Backend myBackend(PORTNUM);
 
    return EXIT_SUCCESS;   
}
