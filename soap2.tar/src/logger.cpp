/**********
** logger.cpp -- class definitions for the Logger class
**
** Project: SOAP2
** Author: Eli Wenig
**
**********/
#include <iostream>
#include <fstream>
#include <cstdlib>
#include <cstdarg>
#include <cstring>
#include "logger.h"

using namespace std;

Logger::Logger(const char* filename) {
	this->outfile.open(filename,ios::app);
	this->useStdout = 0;
	if (!this->outfile.is_open()) {
		cout << "Could not open " << filename << " for writing. Exiting.\n";
		exit(EXIT_FAILURE);
	}
}

Logger::~Logger() {
	this->outfile.close();
}

int Logger::log(const char* logText) {
	if (useStdout) {
		cout << "[" << Logger::nowString() << "] " << logText << endl;
		cout.flush();
	} else {
		outfile << "[" << Logger::nowString() << "] " << logText << endl;
		outfile.flush();
		if (outfile.fail()) {
			cout << "Logfile returned bad, falling back to stdout.\n";
			useStdout = 1;
		}
	}

	return strlen(logText);
}

int Logger::logf(const char* fmt, ...) {
	va_list vl;
	va_start(vl,fmt);
	char *logText;
	vasprintf(&logText,fmt,vl);

	return this->log(logText);
}

const char* Logger::nowString() {
    time_t now;
    struct tm *timeInfo;
    time(&now);
    char *timeStr = ctime(&now);
    //remove trailing "\n"
    timeStr[strlen(timeStr)-1] = 0;
    
    return timeStr;
}

//A logger that anyone can access
extern const char LOGFILE[30];
Logger myLogger(LOGFILE);
