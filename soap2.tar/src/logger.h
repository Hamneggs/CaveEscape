/**********
** logger.h -- class prototype for the Logger class
**
** Project: SOAP2
** Author: Eli Wenig
**
**********/
#ifndef LOGGER_H
#define LOGGER_H
#include <fstream>

using namespace std;

class Logger {
    public:
        Logger(const char*);
	~Logger();
	int log(const char*);
	int logf(const char*, ...);
	static const char* nowString();

    private:
        ofstream outfile;
	int useStdout;
};

#endif
