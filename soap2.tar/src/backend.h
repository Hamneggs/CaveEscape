/**********
** backend.h -- class prototype for the SOAP2 backend
**
** Project: SOAP2
** Author: Eli Wenig
**
**********/
#ifndef BACKEND_H
#define BACKEND_H
#include <xmlrpc-c/base.hpp>
#include <xmlrpc-c/registry.hpp>
#include <xmlrpc-c/server_abyss.hpp>
using namespace xmlrpc_c;

class Backend {
    public:
        Backend(short);

    private:
        registry myReg;
	short port;
};

//Public methods for the XML-RPC server.
class playStream : public method {
    public:
        playStream();
        void execute(paramList const&,
                     value* const);   
};

class crappers : public method {
    public:
        crappers();
        void execute(paramList const&,
                     value* const);   
};
#endif

