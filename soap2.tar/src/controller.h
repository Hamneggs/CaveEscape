/**********
** controller.h -- class prototype for Controller
**
** Project: SOAP2
** Author: Eli Wenig
**
**********/

class Controller {
    
};
